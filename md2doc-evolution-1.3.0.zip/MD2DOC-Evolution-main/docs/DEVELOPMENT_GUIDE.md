# 開發指南 (Development Guide)

本指南旨在協助開發者快速上手 **MD2DOC-Evolution** 的開發環境，並理解日常開發流程。

## ⚙️ 環境建置 (Setup)

### 系統需求
- **Node.js**: v18.0.0 或更高版本 (建議使用 LTS)
- **套件管理器**: npm (預設) 或 yarn/pnpm

### 初次安裝
```bash
# Clone 專案
git clone MD2DOC-Evolution.git
cd BookPublisher_MD2Doc

# 安裝依賴
npm install
```

---

## 📜 可用腳本 (Scripts)

在 `package.json` 中定義了以下常用指令：

| 指令 | 說明 |
| :--- | :--- |
| `npm run dev` | 啟動開發伺服器 (Vite)，預設 port 為 5173。支援 HMR (熱重載)。 |
| `npm run build` | 建置生產環境版本，產物位於 `dist/` 目錄。 |
| `npm run preview` | 在本地預覽 `dist/` 中的建置結果。 |
| `npm run test` | 執行單元測試 (Vitest)。 |

---

## 🐛 除錯技巧 (Debugging)

### 1. Markdown 解析除錯
若發現轉檔結果不如預期，可以先檢查 Parser 的輸出。
在 `services/docxGenerator.ts` 中，可以加入 `console.log(blocks)` 來查看解析後的 AST 結構，確認是否在解析階段就發生錯誤。

### 2. Word 樣式除錯
Word 的樣式除錯較為困難。建議使用 `constants/theme.ts` 中的顏色變數進行視覺化除錯。例如，暫時將某個邊框設為紅色，以確認該樣式是否正確套用到目標元素上。

### 3. Mermaid 圖表問題
Mermaid 渲染失敗通常是因為語法錯誤或 SVG 轉換問題。
- 確認瀏覽器 Console 是否有 Mermaid 相關報錯。
- 檢查 `services/docx/builders/mermaid.ts` 中的 Canvas 繪製邏輯。

---

## 🧪 測試撰寫 (Testing)

我們使用 **Vitest** 進行測試。新增功能時，請務必新增對應的測試案例。

### 測試檔案位置
所有測試位於 `tests/` 目錄下：
- `tests/markdownParser.test.ts`: 測試解析邏輯。
- `tests/docxGenerator.test.ts`: 測試 Word 生成邏輯 (Snapshot Testing)。

### 執行特定測試
```bash
npx vitest tests/markdownParser.test.ts
```

---

## 📦 發布流程 (Release Workflow)

1. 完成功能開發並通過測試。
2. 更新 `package.json` 中的版本號。
3. 更新 `CHANGELOG.md` 記錄變更。
4. 提交 PR 至 `main` 分支。

---

若有任何疑問，歡迎在 Issue 中提出討論。
